<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<script>
if(window.location.protocol == "http:") {
	window.location = document.URL.replace("http://", "https://");
}
if(window.location.hostname.indexOf("www")==0) {
    window.location = document.URL.replace("www.","");
}
</script>
<head>
<meta name="viewport" content="width=984">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InMobi Choice. Consent Manager Tag v3.0 (for TCF 2.2) -->
<script type="text/javascript" async=true>
(function() {
  var host = window.location.hostname;
  var element = document.createElement('script');
  var firstScript = document.getElementsByTagName('script')[0];
  var url = 'https://cmp.inmobi.com'
    .concat('/choice/', 'eAuchLe54ZmBH', '/', host, '/choice.js?tag_version=V3');
  var uspTries = 0;
  var uspTriesLimit = 3;
  element.async = true;
  element.type = 'text/javascript';
  element.src = url;

  firstScript.parentNode.insertBefore(element, firstScript);

  function makeStub() {
    var TCF_LOCATOR_NAME = '__tcfapiLocator';
    var queue = [];
    var win = window;
    var cmpFrame;

    function addFrame() {
      var doc = win.document;
      var otherCMP = !!(win.frames[TCF_LOCATOR_NAME]);

      if (!otherCMP) {
        if (doc.body) {
          var iframe = doc.createElement('iframe');

          iframe.style.cssText = 'display:none';
          iframe.name = TCF_LOCATOR_NAME;
          doc.body.appendChild(iframe);
        } else {
          setTimeout(addFrame, 5);
        }
      }
      return !otherCMP;
    }

    function tcfAPIHandler() {
      var gdprApplies;
      var args = arguments;

      if (!args.length) {
        return queue;
      } else if (args[0] === 'setGdprApplies') {
        if (
          args.length > 3 &&
          args[2] === 2 &&
          typeof args[3] === 'boolean'
        ) {
          gdprApplies = args[3];
          if (typeof args[2] === 'function') {
            args[2]('set', true);
          }
        }
      } else if (args[0] === 'ping') {
        var retr = {
          gdprApplies: gdprApplies,
          cmpLoaded: false,
          cmpStatus: 'stub'
        };

        if (typeof args[2] === 'function') {
          args[2](retr);
        }
      } else {
        if(args[0] === 'init' && typeof args[3] === 'object') {
          args[3] = Object.assign(args[3], { tag_version: 'V3' });
        }
        queue.push(args);
      }
    }

    function postMessageEventHandler(event) {
      var msgIsString = typeof event.data === 'string';
      var json = {};

      try {
        if (msgIsString) {
          json = JSON.parse(event.data);
        } else {
          json = event.data;
        }
      } catch (ignore) {}

      var payload = json.__tcfapiCall;

      if (payload) {
        window.__tcfapi(
          payload.command,
          payload.version,
          function(retValue, success) {
            var returnMsg = {
              __tcfapiReturn: {
                returnValue: retValue,
                success: success,
                callId: payload.callId
              }
            };
            if (msgIsString) {
              returnMsg = JSON.stringify(returnMsg);
            }
            if (event && event.source && event.source.postMessage) {
              event.source.postMessage(returnMsg, '*');
            }
          },
          payload.parameter
        );
      }
    }

    while (win) {
      try {
        if (win.frames[TCF_LOCATOR_NAME]) {
          cmpFrame = win;
          break;
        }
      } catch (ignore) {}

      if (win === window.top) {
        break;
      }
      win = win.parent;
    }
    if (!cmpFrame) {
      addFrame();
      win.__tcfapi = tcfAPIHandler;
      win.addEventListener('message', postMessageEventHandler, false);
    }
  };

  makeStub();

  var uspStubFunction = function() {
    var arg = arguments;
    if (typeof window.__uspapi !== uspStubFunction) {
      setTimeout(function() {
        if (typeof window.__uspapi !== 'undefined') {
          window.__uspapi.apply(window.__uspapi, arg);
        }
      }, 500);
    }
  };

  var checkIfUspIsReady = function() {
    uspTries++;
    if (window.__uspapi === uspStubFunction && uspTries < uspTriesLimit) {
      console.warn('USP is not accessible');
    } else {
      clearInterval(uspInterval);
    }
  };

  if (typeof window.__uspapi === 'undefined') {
    window.__uspapi = uspStubFunction;
    var uspInterval = setInterval(checkIfUspIsReady, 6000);
  }
})();
</script>
<!-- End InMobi Choice. Consent Manager Tag v3.0 (for TCF 2.2) --><link href="css/radiftarin_styles_5.css" rel="stylesheet" type="text/css" />
<link rel="image_src" href="https://img.youtube.com/vi/8Yqv_qiCfz8/hqdefault.jpg" />
<meta name="description" content="&#1582;&#1576;&#1585;&#1607;&#1575;&#1548; &#1608;&#1740;&#1583;&#1740;&#1608;&#1607;&#1575; &#1608; &#1593;&#1705;&#1587;&#8204;&#1607;&#1575;&#1740; &#1575;&#1740;&#1585;&#1575;&#1606; &#1608; &#1580;&#1607;&#1575;&#1606;">
<meta name="keywords" content="iran,news,videos,photos,link,image,news,iran,persian,farsi">

<link rel="apple-touch-icon" sizes="57x57" href="icons/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="icons/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="icons/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="icons/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="icons/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="icons/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="icons/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="icons/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="icons/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="icons/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="icons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="icons/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="icons/favicon-16x16.png">

<meta property="og:image" content="https://img.youtube.com/vi/8Yqv_qiCfz8/hqdefault.jpg" />
<script type="text/javascript" src="https://code.jquery.com/jquery-1.6.2.min.js"></script>
<script type="text/javascript">
$(function() {
		var counter=0;
	var aHighlightItems=new Array();
	var highlightItemHov=false;
	$('div#highlightBar').hover(function() {
		highlightItemHov=true;
	}, function() {
		highlightItemHov=false;
	});
			aHighlightItems[0]='<a style="border:0" href="link_page.php?id=273437">جنگ آمریکا و ایران؛ ماجرای دلفین‌های انتحاری چیست؟</a>';
			aHighlightItems[1]='<a style="border:0" href="link_page.php?id=273436">حملات منتسب به ایران علیه امارات و &quot;آستانه تحمل&quot; ارتش آمریکا</a>';
			aHighlightItems[2]='<a style="border:0" href="link_page.php?id=273435">هگست: ایران در صورت حمله به کشتیرانی تجاری با آتش‌ کوبنده آمریکا روبه‌رو می‌شود</a>';
			aHighlightItems[3]='<a style="border:0" href="link_page.php?id=273434">Trump says US military will guide stranded ships out of Strait of Hormuz in &#39;Project Freedom&#39;</a>';
			aHighlightItems[4]='<a style="border:0" href="link_page.php?id=273433">تلاش دوباره آمریکا و بحرین برای ارائه قطعنامه‌ای جدید به شورای امنیت درباره تنگه هرمز</a>';
			aHighlightItems[5]='<a style="border:0" href="link_page.php?id=273432">۱۹ بازداشتی دی‌ماه در صف اعدام و افشای نام ده‌ها بازداشتی دیگر</a>';
			aHighlightItems[6]='<a style="border:0" href="link_page.php?id=273431">وو ییزه؛ فوق ستاره‌ اسنوکر جهان از آپارتمانی بدون پنجره تا قهرمانی جهان</a>';
			aHighlightItems[7]='<a style="border:0" href="link_page.php?id=273430">ترامپ: جنگ با جمهوری اسلامی ممکن است دو یا سه هفته دیگر طول بکشد</a>';
			aHighlightItems[8]='<a style="border:0" href="link_page.php?id=273429">برده‌داری مدرن در بریتانیا؛ «افزایش ۵۰ درصدی بهره‌کشی جنسی از دختران در پنج سال گذشته»</a>';
			aHighlightItems[9]='<a style="border:0" href="link_page.php?id=273428">Bowen: Strait of Hormuz standoff raises risk of sliding back into all-out war</a>';
			aHighlightItems[10]='<a style="border:0" href="link_page.php?id=273427">میانجی غیرمنتظره؛ پاکستان چگونه پل ارتباطی ایران و آمریکا شد؟</a>';
			aHighlightItems[11]='<a style="border:0" href="link_page.php?id=273426">نفت ایران زیر فشار؛ تداوم تولید یا کاهش اجتناب‌ناپذیر؟</a>';
			aHighlightItems[12]='<a style="border:0" href="link_page.php?id=273425">محکومیت گستردۀ حملات موشکی و پهپادی ایران به امارات؛ عراقچی به امارات تذکر داد</a>';
			aHighlightItems[13]='<a style="border:0" href="link_page.php?id=273424">تشدید تنش‌ها در تنگه هرمز؛ رسانه‌های داخلی: ۵ نفر در حمله به قایق‌های</a>';
			aHighlightItems[14]='<a style="border:0" href="link_page.php?id=273423">استارمر: دخالت ایران یا هر کشور خارجی در تحریک خشونت در بریتانیا بی‌پاسخ نمی‌ماند</a>';
			aHighlightItems[15]='<a style="border:0" href="link_page.php?id=273422">در جستجوی نان از تهران تا استانبول؛ بن‌بست زندگی در ایران بازار</a>';
			aHighlightItems[16]='<a style="border:0" href="link_page.php?id=273421">رویترز: جدول زمانی برای ساخت بمب اتمی ایران تغییری نکرده است</a>';
			aHighlightItems[17]='<a style="border:0" href="link_page.php?id=273420">بن ییشای | حمله به امارات و عمان؛ جمهوری اسلامی مستاصل و سردرگم شده است</a>';
			aHighlightItems[18]='<a style="border:0" href="link_page.php?id=273419">چگونه جنگ ایران زمینه دستگیری یکی از خطرناک‌ترین افراد تحت تعقیب اروپا را در دوبی فراهم کرد؟</a>';
			aHighlightItems[19]='<a style="border:0" href="link_page.php?id=273418">روسیه و اوکراین آتش‌بس یک‌جانبه و جداگانه اعلام کردند</a>';
			aHighlightItems[20]='<a style="border:0" href="link_page.php?id=273417">آمپول‌های لاغری چگونه مصرف روزمره را متحول کردند؟</a>';
			aHighlightItems[21]='<a style="border:0" href="link_page.php?id=273416">شورای سردبیری وال‌استریت ژورنال | رژیم ایران به آتش‌بس پایان داد؛ ترامپ می‌تواند پاسخ دهد</a>';
			aHighlightItems[22]='<a style="border:0" href="link_page.php?id=273415">چرا ارمنستان میزبان رهبران اروپا شده است؟</a>';
			aHighlightItems[23]='<a style="border:0" href="link_page.php?id=273414">عراقچی: پروژه آزادی ترامپ در تنگه هرمز در حقیقت پروژه بن‌بست است</a>';
			aHighlightItems[24]='<a style="border:0" href="link_page.php?id=273413">فیلدمارشال عاصم منیر چطور به چهره محوری میان واشنگتن و تهران بدل شد؟</a>';
			aHighlightItems[25]='<a style="border:0" href="link_page.php?id=273412">حملات به امارات و عمان؛ مواضع متناقض ایران و تهدید ترامپ</a>';
			aHighlightItems[26]='<a style="border:0" href="link_page.php?id=273411">سه مسافر یک کشتی کروز در پی شیوع مشکوک ویروس «هانتا» جان باختند</a>';
			aHighlightItems[27]='<a style="border:0" href="link_page.php?id=273410">UAE accuses Iran of renewed drone and missile attacks</a>';
			aHighlightItems[28]='<a style="border:0" href="link_page.php?id=273409">ایران در واکنش به «پروژه آزادی»، شماری از کشتی‌ها و بندر فجیره امارات را هدف قرار داد</a>';
			aHighlightItems[29]='<a style="border:0" href="link_page.php?id=273408">عادل الحربی | افول نفوذ جمهوری اسلامی و خطر رهاشدگی شبه‌نظامیان در خاورمیانه</a>';
			aHighlightItems[30]='<a style="border:0" href="link_page.php?id=273407">تاپی در مسیر نزول؛ از همکاری چهارجانبه تا محور طالبان-ترکمنستان</a>';
			aHighlightItems[31]='<a style="border:0" href="link_page.php?id=273406">حملات جمهوری اسلامی، سوخت‌رسانی ناوگان آمریکا را از بندر به دریا کشاند</a>';
			aHighlightItems[32]='<a style="border:0" href="link_page.php?id=273405">&quot;عملیات آزادی&quot; ترامپ در تنگه هرمز؛گامی به‌سوی جنگ یا مذاکره؟</a>';
			aHighlightItems[33]='<a style="border:0" href="link_page.php?id=273404">دو کشته و چند مجروح پس از برخورد یک خودرو به جمعیت در لایپزیگ</a>';
			aHighlightItems[34]='<a style="border:0" href="link_page.php?id=273403">هانتاویروس چیست؟</a>';
		function updateHighlightBar() {
		if(!highlightItemHov) {
			$('div#highlightBar').hide().html(aHighlightItems[counter]).slideDown();
			counter==34?counter=0:counter++; 
		}
		setTimeout(function() {
			updateHighlightBar(); // repeat
		}, 8000);
	}
	updateHighlightBar();
	// End HighlightBar
});
</script>

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-VHL9REX4KB"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-VHL9REX4KB');
</script>




<script type="text/javascript" src="js/footballitarin-common.js"></script>



<title>&#1585;&#1583;&#1740;&#1601;&#8204;&#1578;&#1585;&#1740;&#1606; | Be Omid Didar Dar Tehran / مستند به امید دیدار در تهران - ویدیو کامل</title>
</head>

<body>
<div id="outer-wrapper">
	<div id="w984-wrapper">
		<div id="nav_top">
	<ul>
			<li style="width:95px;height:22px;overflow:hidden;"><a target="_blank" style="float:left;margin:0;padding:3px 0 0 8px;" href="https://whos.amung.us/stats/j7s72dzrxn/"><img id="whoscount" src="https://whos.amung.us/swidget/j7s72dzrxn.png"></a>
			<script type="text/javascript">
			$(function() {
				function refwhoscount() {
					var d = new Date();
					var newURL = "https://whos.amung.us/swidget/j7s72dzrxn.png?"+d.getTime();
					$("#whoscount").attr("src", newURL);
					
					setTimeout(function() {
						refwhoscount(); // repeat
					}, 30000);
				}
				refwhoscount();
			});
			</script>
		</li>
		    		<li class="page_item"><a href="profile.php">&#1581;&#1587;&#1575;&#1576; &#1705;&#1575;&#1585;&#1576;&#1585;&#1740;</a></li>
		<li class="page_item"><a href="terms_and_conditions.php">&#1602;&#1608;&#1575;&#1606;&#1740;&#1606; &#1587;&#1575;&#1740;&#1578;</a></li>
		<li class="page_item"><a href="contact.php">&#1578;&#1605;&#1575;&#1587; &#1576;&#1575; &#1605;&#1575;</a></li>
		<li class="page_item"><a href="blog.php">&#1608;&#1576;&#1604;&#1575;&#1711;</a></li>
		<li class="page_item"><a href="ad_request.php">&#1578;&#1576;&#1604;&#1740;&#1594;&#1575;&#1578;</a></li>
		<li class="page_item"><a href="farsi_persian_keyboard.php">&#1589;&#1601;&#1581;&#1607;&#8204;&#1705;&#1604;&#1740;&#1583; &#1601;&#1575;&#1585;&#1587;&#1740;</a></li>
    	</ul>
	
	
	<span class="tehTime">
		&#1587;&#1607;&#8204;&#1588;&#1606;&#1576;&#1607;&#1548; &#1777;&#1781; &#1575;&#1585;&#1583;&#1740;&#1576;&#1607;&#1588;&#1578; &#1777;&#1780;&#1776;&#1781; (<span dir="ltr">5 May 2026</span>)&#1548; &#1587;&#1575;&#1593;&#1578; &#1778;&#1777;:&#1776;&#1780; (&#1576;&#1607; &#1608;&#1602;&#1578; &#1575;&#1740;&#1585;&#1575;&#1606;)	
	</span>
	<div class="clear"></div>
</div><div id="nav_highlight">
	<div class="highlight_items" id="highlightBar"></div>
		<div class="fbTopButton">
		<iframe src="//www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2Fradiftarin&amp;send=false&amp;layout=button_count&amp;width=130&amp;show_faces=false&amp;font=tahoma&amp;colorscheme=dark&amp;action=like&amp;height=21" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:130px; height:21px; margin-top:1px;" allowTransparency="true"></iframe>
	</div>
		<div class="clear"></div>
</div><div id="header-wrapper">
		<div id="header-logo">
				<a href="https://radiftarin.com/"><img border="0" src="images/Radiftarin_Logo.png"></a>
	</div>
	<div class="clear"></div>
</div><div id="main_nav" class="subbed">
	<ul>
		<li><a href="/">&#1582;&#1575;&#1606;&#1607;</a></li>
		<li><a href="links.php">&#1582;&#1576;&#1585;&#1607;&#1575;</a></li>
		<li><a href="videos.php" class="mainNavSelected">&#1608;&#1740;&#1583;&#1740;&#1608;&#1607;&#1575;</a></li>
		<li><a href="images.php">&#1593;&#1705;&#1587;&#8204;&#1607;&#1575;</a></li>
		<li><a href="constitution.php">&#1602;&#1575;&#1606;&#1608;&#1606;&#8204;&#1575;&#1587;&#1575;&#1587;&#1740;</a></li>
	</ul>
	
	<div class="searchform">
		<form action="search_results.php" method="GET">
			<input id="s" class="searchInput" name="q" type="text" value="&#1580;&#1587;&#1578;&#1580;&#1608;..." descval="&#1580;&#1587;&#1578;&#1580;&#1608;..." />
			<input alt="&#1580;&#1587;&#1578;&#1580;&#1608;" class="search_btn" src="images/i_search.png" type="image"/>
		</form>
	</div>
</div>

<div id="sub_nav">
		<div class="list_select_div">
		<form method="GET" action="videos.php">
			<select class="" name="cupID" id="cupID" onchange="JavaScript:submit()">
<option value="">&#1583;&#1587;&#1578;&#1607;&#8204;&#1576;&#1606;&#1583;&#1740; &#1608;&#1740;&#1583;&#1740;&#1608;&#1607;&#1575;...</option>
<option value="1">فیلم‌سینمایی</option>
<option value="2">موسیقی</option>
<option value="4">سرگرمی</option>
<option value="5">آشپزی</option>
<option value="6">خبری</option>
<option value="7">اجتماعی</option>
</select>
		</form>
	</div>
		<ul>
		<li><a href="videos.php">&#1578;&#1575;&#1586;&#1607;&#8204;&#1578;&#1585;&#1740;&#1606; &#1608;&#1740;&#1583;&#1740;&#1608;&#1607;&#1575;</a></li>
		<li><a href="videos.php?sType=1">&#1583;&#1575;&#1594;&#8204;&#1578;&#1585;&#1740;&#1606;&#8204;&#1607;&#1575;&#1740; &#1607;&#1601;&#1578;&#1607;</a></li>
		<li><a href="videos.php?sType=4">&#1583;&#1575;&#1594;&#8204;&#1578;&#1585;&#1740;&#1606;&#8204;&#1607;&#1575;&#1740; &#1605;&#1575;&#1607;</a></li>
		<li><a href="videos.php?sType=3">&#1576;&#1581;&#1579;&#8204;&#1576;&#1585;&#1575;&#1606;&#1711;&#1740;&#1586;&#1578;&#1585;&#1740;&#1606;&#8204;&#1607;&#1575;</a></li>
			</ul>
</div>




		<div id="content-wrapper"><div id="list_left">
	<div id="tabligh_300">
	<a href="https://radiftarin.com/link.php?xaid=iy8fy1sh5l9kdvnsg11y" target="_blank"><img src="https://2.bp.blogspot.com/-Hew7ktqFUdk/WvUH0wZF0hI/AAAAAAAABAY/BA2MFsCbsmkYRdIqqI_6hhMvJfMfs_O6ACLcBGAs/s1600/follow_fb.jpg" width="300" height="75"></a>
</div>



<div id="news_section_wide">
	<ul><li><a href="link_page.php?id=273437">جنگ آمریکا و ایران؛ ماجرای دلفین‌های انتحاری چیست؟</a></li><li><a href="link_page.php?id=273436">حملات منتسب به ایران علیه امارات و &quot;آستانه تحمل&quot; ارتش آمریکا</a></li><li><a href="link_page.php?id=273435">هگست: ایران در صورت حمله به کشتیرانی تجاری با آتش‌ کوبنده آمریکا روبه‌رو می‌شود</a></li><li class="en_item"><a href="link_page.php?id=273434">Trump says US military will guide stranded ships out of Strait of Hormuz in &#39;Project Freedom&#39; (BBC News)</a></li><li><a href="link_page.php?id=273433">تلاش دوباره آمریکا و بحرین برای ارائه قطعنامه‌ای جدید به شورای امنیت درباره تنگه هرمز</a></li><li><a href="link_page.php?id=273432">۱۹ بازداشتی دی‌ماه در صف اعدام و افشای نام ده‌ها بازداشتی دیگر</a></li><li><a href="link_page.php?id=273431">وو ییزه؛ فوق ستاره‌ اسنوکر جهان از آپارتمانی بدون پنجره تا قهرمانی جهان</a></li><li><a href="link_page.php?id=273430">ترامپ: جنگ با جمهوری اسلامی ممکن است دو یا سه هفته دیگر طول بکشد</a></li><li><a href="link_page.php?id=273429">برده‌داری مدرن در بریتانیا؛ «افزایش ۵۰ درصدی بهره‌کشی جنسی از دختران در پنج سال گذشته»</a></li><li class="en_item"><a href="link_page.php?id=273428">Bowen: Strait of Hormuz standoff raises risk of sliding back into all-out war (BBC News)</a></li><li><a href="link_page.php?id=273427">میانجی غیرمنتظره؛ پاکستان چگونه پل ارتباطی ایران و آمریکا شد؟</a></li><li><a href="link_page.php?id=273426">نفت ایران زیر فشار؛ تداوم تولید یا کاهش اجتناب‌ناپذیر؟</a></li><li><a href="link_page.php?id=273425">محکومیت گستردۀ حملات موشکی و پهپادی ایران به امارات؛ عراقچی به امارات تذکر داد</a></li><li><a href="link_page.php?id=273424">تشدید تنش‌ها در تنگه هرمز؛ رسانه‌های داخلی: ۵ نفر در حمله به قایق‌های</a></li><li><a href="link_page.php?id=273423">استارمر: دخالت ایران یا هر کشور خارجی در تحریک خشونت در بریتانیا بی‌پاسخ نمی‌ماند</a></li><li><a href="link_page.php?id=273422">در جستجوی نان از تهران تا استانبول؛ بن‌بست زندگی در ایران بازار</a></li><li><a href="link_page.php?id=273421">رویترز: جدول زمانی برای ساخت بمب اتمی ایران تغییری نکرده است</a></li><li><a href="link_page.php?id=273420">بن ییشای | حمله به امارات و عمان؛ جمهوری اسلامی مستاصل و سردرگم شده است</a></li><li><a href="link_page.php?id=273419">چگونه جنگ ایران زمینه دستگیری یکی از خطرناک‌ترین افراد تحت تعقیب اروپا را در دوبی فراهم کرد؟</a></li><li><a href="link_page.php?id=273418">روسیه و اوکراین آتش‌بس یک‌جانبه و جداگانه اعلام کردند</a></li><li><a href="link_page.php?id=273417">آمپول‌های لاغری چگونه مصرف روزمره را متحول کردند؟</a></li><li><a href="link_page.php?id=273416">شورای سردبیری وال‌استریت ژورنال | رژیم ایران به آتش‌بس پایان داد؛ ترامپ می‌تواند پاسخ دهد</a></li><li><a href="link_page.php?id=273415">چرا ارمنستان میزبان رهبران اروپا شده است؟</a></li><li><a href="link_page.php?id=273414">عراقچی: پروژه آزادی ترامپ در تنگه هرمز در حقیقت پروژه بن‌بست است</a></li><li><a href="link_page.php?id=273413">فیلدمارشال عاصم منیر چطور به چهره محوری میان واشنگتن و تهران بدل شد؟</a></li><li><a href="link_page.php?id=273412">حملات به امارات و عمان؛ مواضع متناقض ایران و تهدید ترامپ</a></li><li><a href="link_page.php?id=273411">سه مسافر یک کشتی کروز در پی شیوع مشکوک ویروس «هانتا» جان باختند</a></li><li class="en_item"><a href="link_page.php?id=273410">UAE accuses Iran of renewed drone and missile attacks (BBC News)</a></li><li><a href="link_page.php?id=273409">ایران در واکنش به «پروژه آزادی»، شماری از کشتی‌ها و بندر فجیره امارات را هدف قرار داد</a></li><li><a href="link_page.php?id=273408">عادل الحربی | افول نفوذ جمهوری اسلامی و خطر رهاشدگی شبه‌نظامیان در خاورمیانه</a></li><li><a href="link_page.php?id=273407">تاپی در مسیر نزول؛ از همکاری چهارجانبه تا محور طالبان-ترکمنستان</a></li><li><a href="link_page.php?id=273406">حملات جمهوری اسلامی، سوخت‌رسانی ناوگان آمریکا را از بندر به دریا کشاند</a></li><li><a href="link_page.php?id=273405">&quot;عملیات آزادی&quot; ترامپ در تنگه هرمز؛گامی به‌سوی جنگ یا مذاکره؟</a></li><li><a href="link_page.php?id=273404">دو کشته و چند مجروح پس از برخورد یک خودرو به جمعیت در لایپزیگ</a></li><li><a href="link_page.php?id=273403">هانتاویروس چیست؟</a></li><li><a href="link_page.php?id=273402">سونامی بیکاری در ایران؛ ویرانی گسترده در اقتصاد و خانواده ایرانی</a></li><li><a href="link_page.php?id=273401">با حضور مین‌روب پیشرفته فولدا؛ آماده‌باش آلمان برای کمک به بازگشایی</a></li><li><a href="link_page.php?id=273400">تاثیر غیرمنتظره جنگ ایران بر اوکراین؛ آتش‌بس با روسیه نزدیک است؟</a></li><li class="en_item"><a href="link_page.php?id=273399">What we know about Trump&#39;s &#39;Project Freedom&#39; in Strait of Hormuz (BBC News)</a></li><li><a href="link_page.php?id=273398">بانک سپه در صدمین سال تاسیس؛ نخستین بانک ایرانی چگونه به قلک سپاه</a></li><li><a href="link_page.php?id=273397">سبک‌تر از یک قالب صابون؛ کفش‌هایی که رکورد ماراتن را در هم شکستند</a></li><li><a href="link_page.php?id=273396">از اینستاگرام تا مشاغل خانگی و شرکت‌های نوپا؛ قطع اینترنت چگونه نان</a></li><li><a href="link_page.php?id=273395">ایران سه نفر از معترضان ۱۸ و ۱۹ دی را اعدام کرد </a></li><li><a href="link_page.php?id=273394">فایننشال تایمز: جمهوری اسلامی علیه مخالفانش در خارج از کشور جنگ پنهان</a></li><li><a href="link_page.php?id=273393">سازمان ملل: با افزایش بدهی‌های دولت‌ها دست‌کم ۵۵ میلیون شغل برای زنان از دست می‌رود</a></li><li><a href="link_page.php?id=273392">«ثروتِ جانشینی»؛ مجتبی خامنه‌ای و پرسش دربارهٔ «دزدسالاریِ موروثی» در جمهوری اسلامی</a></li><li><a href="link_page.php?id=273391">واکنش به کاهش نیروهای آمریکا در آلمان؛ دبیرکل ناتو: در حال افزایش همکاری‌‌ها هستیم</a></li><li><a href="link_page.php?id=273390">راز زیمت | آتش‌بس ایران و آمریکا فقط تعویق یک جنگ اجتناب‌ناپذیر است</a></li><li><a href="link_page.php?id=273389">بدر السنبل | رهبر جمهوری اسلامی به سخنگوی سپاه پاسداران بدل شده است؟</a></li><li><a href="link_page.php?id=273388">ارمنستان و جمهوری آذربایجان؛ چگونه می‌توان بر نفرت موجود غلبه کرد؟</a></li><li><a href="link_page.php?id=273387">سالم الکتبی | رژیم حاکم بر ایران با سکوت جهان آموخت که تهدید جواب می‌دهد</a></li><li><a href="link_page.php?id=273386">آیا پروژه «چهار دریا» سوریه می‌تواند جایگزین تنگه هرمز شود؟</a></li><li><a href="link_page.php?id=273385">عواقب جنگ آمریکا با ایران؛ ورشکستگی خطوط هوایی اسپریت بلیت هواپیما در آمریکا را گران خواهد کرد</a></li><li><a href="link_page.php?id=273384">راز سی‌ساله قتل بدون جسد؛ چه بر سر آرلین آمد؟</a></li><li class="en_item"><a href="link_page.php?id=273383">Trump says US to &#39;guide&#39; stranded ships through Strait of Hormuz (BBC News)</a></li><li><a href="link_page.php?id=273382">سنتکام از آغاز طرح ترامپ برای عبور دادن کشتی‌های تجاری از تنگه هرمز خبر داد</a></li><li><a href="link_page.php?id=273381">«پروژه آزادی»؛ نیروی دریایی آمریکا از دوشنبه کشتی‌ها را از تنگه هرمز</a></li><li class="en_item"><a href="link_page.php?id=273380">Deepening fear for some in Iran as regime shows no sign of compromise (BBC News)</a></li><li><a href="link_page.php?id=273379">چرا یک پست در شبکه‌های اجتماعی می‌تواند در کشورهای خلیج فارس به زندان یا اخراج ختم شود؟</a></li><li><a href="link_page.php?id=273378">ترامپ: پیشنهاد جدید تهران پذیرفتنی نیست</a></li><li><a href="link_page.php?id=273377">افزایش نگرانی‌ها از وخامت سلامت نرگس محمدی</a></li><li class="en_item"><a href="link_page.php?id=273376">Iran says US has responded to its latest peace proposal (BBC News)</a></li><li><a href="link_page.php?id=273375">ویدیوی خوشگذرانی در کیش؛ هوش مصنوعی، تبلیغات اغراق‌شده یا مقاومت جامعه در سایه جنگ؟</a></li><li><a href="link_page.php?id=273374">۶۵ روز تاریکی دیجیتال در ایران؛ آنها که به اینترنت جهانی وصل شده‌اند می‌گویند بدون دیگران خیلی سوت‌وکور است</a></li><li><a href="link_page.php?id=273373">تشدید سرکوب رسانه‌ای و خلاء اطلاعاتی در ایران در پی جنگ</a></li><li><a href="link_page.php?id=273372">ترامپ: طرح جدید ایران را به‌زودی بررسی می‌کنم؛ «بعید است قابل قبول باشد»</a></li><li><a href="link_page.php?id=273371">دلار در آستانه ۲۰۰هزار تومان و دست خالی جمهوری اسلامی</a></li><li><a href="link_page.php?id=273370">دستور حذف شرکت‌های پیمانکاری تامین نیروی کار؛ تصمیمی پرابهام و</a></li><li><a href="link_page.php?id=273369">پشت پرده امنیتی قطع اینترنت؛ وزارت ارتباطات می‌گوید در آن نقشی ندارد</a></li><li><a href="link_page.php?id=273368">از اعترافات تلویزیونی تا بی‌قبری؛ نیم‌قرن اعدام سیاسی</a></li><li><a href="link_page.php?id=273367">تنها حمام به‌جا‌مانده از یهودیان در افغانستان پس از بازسازی به فروش</a></li><li><a href="link_page.php?id=273366">گروگانگیری، شکنجه و تجاوز؛ گروه‌های تبهکار افغان در مسیر بالکان</a></li><li><a href="link_page.php?id=273365">گروه‌های مرتبط با ایران متهم به تلاش برای بی‌ثبات کردن سوریه</a></li><li><a href="link_page.php?id=273364">فرودگاه هیترو لندن: جنگ ایران ممکن است تعداد مسافران را کاهش دهد</a></li><li><a href="link_page.php?id=273363">رونق قمار و شرط‌‌‌‌بندی در ایران، بازتابی از ناامیدی و فشار معیشتی</a></li><li><a href="link_page.php?id=273362">قوه قضائیه ایران محراب عبدالله‌زاده از بازداشت‌شدگان اعتراضات ۱۴۰۱ را اعدام کرد</a></li><li><a href="link_page.php?id=273361">شبکه‌ای مخفی که استارلینک را به داخل ایران قاچاق می‌کند</a></li><li><a href="link_page.php?id=273360">صندوق‌های بازنشستگی زیر دو تیغ، فساد داخلی و فشار خارجی در ایران</a></li><li><a href="link_page.php?id=273359">ترامپ: جمهوری اسلامی بهای کارهایش را نپرداخته و شاید دوباره به آنها</a></li><li><a href="link_page.php?id=273358">جنگ، «لوبیای سحرآمیز» و «سوپرانقلابی‌ها»؛ تلاش تندورها در ایران برای گرفتن سکان زمامداری</a></li><li><a href="link_page.php?id=273357">جنگ ایران چگونه تورم و رکود جهانی را شعله‌ور می‌کند؟</a></li><li><a href="link_page.php?id=273356">تغییر نقشه سفر ایرانیان؛ زیان اقامتگاه‌های بومگردی و محدود شدن هرچه</a></li><li><a href="link_page.php?id=273355">چرا سم آلتمن و ایلان ماسک، دعوای خود را به دادگاه کشانده‌اند؟</a></li><li><a href="link_page.php?id=273354">«من بی‌وطن بودم، کویتی شدم و دوباره بی‌وطن»؛ چرا هزاران نفر در کویت تابعیت خود را از دست می‌دهند؟</a></li><li class="en_item"><a href="link_page.php?id=273353">Smuggling Starlink tech into Iran to beat the internet blackout (BBC News)</a></li><li><a href="link_page.php?id=273352">پیامدهای جنگ ایران؛ توقف پروازهای شرکت هواپیمایی اسپریت آمریکا</a></li><li><a href="link_page.php?id=273351">یک نفتکش در سواحل یمن ربوده و به سمت سومالی منتقل شد</a></li><li><a href="link_page.php?id=273350">ابراز انزجار ناهید شیرپیشه از هتاکی به خانواده بختیاری پس از انتشار پیام انتقادی همسرش خطاب به رضا پهلوی</a></li><li><a href="link_page.php?id=273349">چین از اجرای تحریم‌های آمریکا علیه ایران تبعیت نخواهد کرد</a></li><li class="en_item"><a href="link_page.php?id=273348">Calls grow over hospital care for jailed Iranian Nobel laureate Narges Mohammadi (BBC News)</a></li><li><a href="link_page.php?id=273347">آمریکا شرکت‌های کشتیرانی را تهدید کرد که در صورت پرداخت عوارض به ایران تحریم می‌شوند</a></li><li><a href="link_page.php?id=273346">استعفای دسته‌جمعی هیئت داوران دوسالانهٔ ونیز در پی مناقشه بر سر حضور روسیه و اسرائیل</a></li><li><a href="link_page.php?id=273345">انتقال نرگس محمدی از زندان به بیمارستان؛ وضعیت او «وخیم و ناپایدار» است</a></li><li><a href="link_page.php?id=273344">تحصن گروهی از جوانان ایرانی در دوسلدورف</a></li><li><a href="link_page.php?id=273343"> تنش لفظی ترامپ و مرتس درباره جنگ ایران؛ آمریکا پنج هزار نیروی خود را از آلمان خارج می‌کند</a></li><li class="en_item"><a href="link_page.php?id=273342">Strait of Hormuz: US warns ship firms could face sanctions if paying Iran tolls (BBC News)</a></li><li><a href="link_page.php?id=273341">گزارش‌ها از وخامت بازار کار در ایران؛ «بیش از یک‌ میلیون شغل از دست رفته است»</a></li><li><a href="link_page.php?id=273340">رویترز: ترامپ گزینه محاصره طولانی‌مدت تنگه هرمز را در نظر دارد</a></li><li><a href="link_page.php?id=273339">صرافی نوبیتکس وابسته به «خرازی»‌ها چطور با ارز دیجیتال پولشویی می‌کند؟</a></li><li><a href="link_page.php?id=273338">زندگی در تعلیق؛ فرسایش روانی جامعه در وضعیت &quot;نه جنگ نه صلح&quot;</a></li></ul></div></div>

<div id="list_right">
		<div class="item_section">
		<table border="0" dir="rtl">
			<tr>
				<td valign="top" width="499">
					<div class="item_page_title">Be Omid Didar Dar Tehran / مستند به امید دیدار در تهران - ویدیو کامل</div>
					<div class="item_labels">					</div>
				</td>
				<td valign="top" width="150" align="left" class="feedback_count">	<table border="0" dir="ltr">
		<tr>
			<td width="45" height="50" align="center" class="largeTD3" vid="3"><span>&#1776;</span></td>
			<td width="45" align="center" class="largeTD2" vid="2"><span>&#1776;</span></td>
			<td width="45" align="center" class="largeTD1" vid="1"><span>&#1776;</span></td>
		</tr>
	</table>
	</td>
				</tr>
				<tr>
									<td colspan="2" height="32" valign="bottom">
						<table class="feedback_share" border="0" width="100%">
							<tr>
								<td height="32" width="110" valign="middle"><span class="icon_holder"><img width="20" height="20" class="rollover zoomIcon keepZoom v1" src="images/share_icon_ball_off.jpg" hover="images/share_icon_ball_on.jpg" vid="1" vrid="34530001" otid="4" oid="336316"><img width="20" height="20" class="rollover zoomIcon keepZoom v2" src="images/share_icon_yellow_off.jpg" hover="images/share_icon_yellow_on.jpg" vid="2" vrid="34530001" otid="4" oid="336316"><img width="20" height="20" class="rollover zoomIcon keepZoom v3" src="images/share_icon_red_off.jpg" hover="images/share_icon_red_on.jpg" vid="3" vrid="34530001" otid="4" oid="336316"></span></td>
								<td valign="middle">&nbsp;</td>
								<td width="190" valign="middle"><iframe style="border:none; margin:0 0 0 0; padding:0; overflow:hidden; width:190px; height:21px;"" src=" //www.facebook.com/plugins/like.php?locale=fa_IR&amp;href=https%3A%2F%2Fradiftarin.com%2Fvideo_page.php%3Fid%3D336316&amp;send=true&amp;layout=button_count&amp;width=190&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font=tahoma&amp;height=21" scrolling="no"
											frameborder="0" allowTransparency="true"></iframe></td>
								<td width="100" valign="middle">
																										<td width="194" valign="middle" align="left">&#1778;&#1783; &#1605;&#1585;&#1583;&#1575;&#1583; &#1777;&#1780;&#1776;&#1779; (<span dir="ltr">17 August 2024</span>)</td>
															</tr>
						</table>
					</td>
							</tr>
			<tr>
				<td colspan="2" align="right"><img src="images/feedback_bg.jpg" width="649" height="8"></td>
			</tr>
		</table>

		
		<table border="0" cellpadding="0" cellspacing="0" align="center" width="100%">
			<tr>
				<td valign="top" align="right" width="110"><a href="controller.php?t=4&d=2&action=nextprev&id=336316"><img border="0" height="53" src="images/video_prev.jpg" style="margin:10px 0 10px 0;"></a></td>
				<td valign="middle" align="center">
											<br>
									</td>
				<td valign="top" align="left" width="110"><a href="controller.php?t=4&d=1&action=nextprev&id=336316"><img border="0" height="53" src="images/video_next.jpg" style="margin:10px 0 10px 0;"></a></td>
			</tr>
		</table>

		<table border="0" width="649" align="center">
							<tr>
					<td valign="top" colspan="2" width="649">
						<iframe align="middle" width="649" height="440" src="https://www.youtube.com/embed/8Yqv_qiCfz8?rel=0&autoplay=0&modestbranding=0&showinfo=0&iv_load_policy=3&cc_load_policy=0" frameborder="0"  webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>					</td>
				</tr>
					</table>

			</div>

	<div class="comments_box">


<div id="sortedByTime">
</div>


<div class="makeComment">&#8592; &#1604;&#1591;&#1601;&#1575;&#1611; <a href="register.php" class="stdLink2">&#1579;&#1576;&#1578;&#8204;&#1606;&#1575;&#1605; &#1705;&#1606;&#1740;&#1583;</a> &#1740;&#1575; <a href="login.php" class="stdLink2">&#1608;&#1575;&#1585;&#1583;&#1588;&#1608;&#1740;&#1583;</a> &#1608; &#1606;&#1592;&#1585; &#1582;&#1608;&#1583; &#1585;&#1575; &#1575;&#1590;&#1575;&#1601;&#1607; &#1705;&#1606;&#1740;&#1583;.</div>


</div>
			<style>
		div.amazon_box {
			background-color: #FFFFFF;
			padding: 20px;
			border-radius: 10px;
			margin: 0 5px 5px 0;
			overflow: hidden;
		}

		div.amazon_box table.azframes tr td {
			padding-left: 12px;
		}
	</style>
	<div class="amazon_box" id="amazon_affiliate">
		<table border="0" width="100%">
			
			
			
		</table>
	</div>

	</div></div>
<div class="clear"></div>


<div id="footer-wrapper">
	<div id="footer">
		<a href="https://radiftarin.com/">Radiftarin.com</a> | Copyright &copy; 2014-2026		| <a href="terms_and_conditions.php">Terms and Conditions</a> | <a href="privacy_policy.php">Privacy Policy</a> | &#1705;&#1604;&#1740;&#1607; &#1581;&#1602;&#1608;&#1602; &#1605;&#1581;&#1601;&#1608;&#1592; &#1575;&#1587;&#1578;
	</div>
</div>

</div>
</div>

	<img style="display:none" src="images/nav_bg_h.png" border="0">
	<img style="display:none" src="images/sub_bg_h.png" border="0">
	<img style="display:none" src="images/ext_bg_h.png" border="0">
	<img style="display:none" src="images/thumbs_up_1.jpg" border="0">
	<img style="display:none" src="images/icon_ball_large_on.jpg" border="0">
	<img style="display:none" src="images/icon_yellow_large_on.jpg" border="0">
	<img style="display:none" src="images/icon_red_large_on.jpg" border="0">
	<img style="display:none" src="images/icon_ball_on.jpg" border="0">
	<img style="display:none" src="images/icon_yellow_on.jpg" border="0">
	<img style="display:none" src="images/icon_red_on.jpg" border="0">
	<img style="display:none" src="images/share_icon_ball_on.jpg" border="0">
	<img style="display:none" src="images/share_icon_yellow_on.jpg" border="0">
	<img style="display:none" src="images/share_icon_red_on.jpg" border="0">


<div class="clear"></div>


</body>

</html>
